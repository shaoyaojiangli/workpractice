#ifndef __USER_H_
#define __USER_H_

// 需要的内容
#include "public.h"
#include "string.h"
#include "stdlib.h"
#include "time.h"
// 对外暴露的内容
extern void Enroll();
extern int Login();
#endif
